import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import urllib.request

ROOT = pathlib.Path('/home/hamza/gap2idea-baselines')
SPECS = {
    '4B': ('e87f176479d0855a907a41277aca2f8ee7a09523', [('Qwen3.5-4B-BF16.gguf', '9e6e2841a75f503ccb330831832fd7861266e187e0dbf149a954219ccb8c197a')]),
    '9B': ('3885219b6810b007914f3a7950a8d1b469d598a5', [('Qwen3.5-9B-BF16.gguf', 'daebe40eeea7057c1cdf35ac56d13f507d8bf12171bbb7a6b6b0d3f05439159a')]),
    '27B': ('3221f178a6b842d04f1fb42f1c413534adcc0a6a', [
        ('BF16/Qwen3.5-27B-BF16-00001-of-00002.gguf', 'c834354ad4ddc2054ac400842ea20d8801bd6718f6cda95baeed6796b5e17e4f'),
        ('BF16/Qwen3.5-27B-BF16-00002-of-00002.gguf', 'cd31f613eff781cde1bfe2b897a1eb37104bf0072a7bc5d1b4e9d363bd75a9bc')]),
}

def download(size):
    revision, files = SPECS[size]
    out = ROOT / 'weights' / size
    out.mkdir(parents=True, exist_ok=True)
    for filename, expected in files:
        path = out / pathlib.Path(filename).name
        url = f'https://huggingface.co/unsloth/Qwen3.5-{size}-GGUF/resolve/{revision}/{filename}'
        print('downloading', size, filename, flush=True)
        with (out / 'download.log').open('a') as log:
            subprocess.run(['curl', '-fL', '--retry', '8', '--retry-delay', '3', '-C', '-', '-o', str(path), url],
                           stdout=log, stderr=log, check=True)
        h = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda: f.read(16 * 1024 * 1024), b''):
                h.update(block)
        if h.hexdigest() != expected:
            raise ValueError(f'Checksum mismatch: {path}')
        print('verified', size, path.name, flush=True)
    (out / 'source.json').write_text(json.dumps(dict(repo=f'unsloth/Qwen3.5-{size}-GGUF', revision=revision, files=files), indent=2))
    if size != '27B':
        modelfile = out / 'Modelfile'
        modelfile.write_text(f'FROM {path}\nPARAMETER num_ctx 131072\nPARAMETER temperature 0\nPARAMETER repeat_penalty 1\n')
        subprocess.run([str(ROOT / 'runtime/bin/ollama'), 'create', f'qwen3.5-{size.lower()}-bf16', '-f', str(modelfile)],
                       env=__import__('os').environ | {'OLLAMA_HOST':'127.0.0.1:11445'}, check=True)
        print('imported', size, flush=True)

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(download, SPECS):
            pass
