import hashlib
import json
import os
import pathlib
import subprocess
import time

root=pathlib.Path('/home/hamza/gap2idea-baselines')
source=root/'weights/legacy38-fp8'
while not (source/'VERIFIED').exists():
    time.sleep(10)
out=root/'weights/legacy38-f16'
out.mkdir(parents=True,exist_ok=True)
model=out/'Qwen3.8-27B-FP8-dequant-F16.gguf'
env=os.environ | {'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4'}
subprocess.run([str(root/'convert-venv/bin/python'), str(root/'llama.cpp/convert_hf_to_gguf.py'),
    str(source),'--outfile',str(model),'--outtype','f16'],env=env,check=True)
h=hashlib.sha256()
with model.open('rb') as f:
    for block in iter(lambda:f.read(16*1024*1024),b''): h.update(block)
provenance=dict(source_repo='Qwen/Qwen3.8-27B-FP8',
    source_revision=(source/'VERIFIED').read_text(), gguf_sha256=h.hexdigest(),
    converter_commit=subprocess.check_output(['git','-C',str(root/'llama.cpp'),'rev-parse','HEAD'],text=True).strip(),
    conversion='FP8 checkpoint dequantized to F16 for V100; different backend/arithmetic from published FP8/vLLM. No claim of bitwise reproduction.',
    source_files=json.loads((source/'download-provenance.json').read_text())['siblings'])
(out/'source.json').write_text(json.dumps(provenance,indent=2))
mf=out/'Modelfile'
mf.write_text(f'FROM {model}\nPARAMETER num_ctx 131072\nPARAMETER temperature 0\nPARAMETER repeat_penalty 1\n')
subprocess.run([str(root/'runtime/bin/ollama'),'create','qwen3.8-27b-fp8-dequant-f16','-f',str(mf)],
    env=os.environ | {'OLLAMA_HOST':'127.0.0.1:11445'},check=True)
print('Historical checkpoint converted and imported',flush=True)
