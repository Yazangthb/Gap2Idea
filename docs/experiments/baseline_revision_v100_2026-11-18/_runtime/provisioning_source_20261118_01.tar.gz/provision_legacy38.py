"""Download the exact historical checkpoint; do not substitute another Qwen3.8 revision."""
import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import urllib.request

root = pathlib.Path('/home/hamza/gap2idea-baselines')
out = root/'weights/legacy38-fp8'
out.mkdir(parents=True, exist_ok=True)
repo = 'Qwen/Qwen3.8-27B-FP8'
revision = '017b9c7af6b5689d5dd426a76e0bc077eb5ca20a'
with urllib.request.urlopen(f'https://huggingface.co/api/models/{repo}/revision/{revision}?blobs=true', timeout=60) as r:
    data = json.load(r)
files = [f for f in data['siblings'] if f['rfilename'].endswith(('.safetensors','.json','.jinja','.model'))]
(out/'download-provenance.json').write_text(json.dumps(data,indent=2))

def download(spec):
    name = spec['rfilename']
    path = out/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with (out/'download.log').open('a') as log:
        subprocess.run(['curl','-fL','--retry','8','--retry-delay','3','-C','-','-o',str(path),
            f'https://huggingface.co/{repo}/resolve/{revision}/{name}'],stdout=log,stderr=log,check=True)
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    if 'lfs' in spec:
        assert h.hexdigest()==spec['lfs']['sha256'], name
    else:
        b=path.read_bytes()
        assert hashlib.sha1(b'blob %d\0'%len(b)+b).hexdigest()==spec['blobId'], name
    print('verified',name,flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(download,files))
(out/'VERIFIED').write_text(revision)
print('Exact historical checkpoint downloaded and verified',flush=True)
