import hashlib
import json
import pathlib
import time
import zipfile

root=pathlib.Path('/home/hamza/gap2idea-baselines')
dest=root/'checkpoints'
dest.mkdir(exist_ok=True)
archive=dest/('completed-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'.zip')
hashes={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for plan_path in sorted((root/'Gap2Idea/docs/experiments').glob('baseline_revision_v100_*_plan.json')):
        plan=json.loads(plan_path.read_text())
        run_root=pathlib.Path(plan['output_root'])
        files=set()
        for summary in run_root.glob('*/*/*.summary.json'):
            stem=summary.name.removesuffix('.summary.json')
            for suffix in ['.jsonl','.manifest.json','.prompt.txt','.summary.json']:
                files.add(summary.with_name(stem+suffix))
        files.update(run_root.glob('*/smoke_report.json'))
        files.update(run_root.glob('*/test_report.json'))
        files.update(run_root.glob('*/runtime_allocation_*.json'))
        files.update(p for p in (run_root/'handover').glob('*') if p.is_file())
        for path in sorted(files):
            data=path.read_bytes()
            rel=run_root.name+'/'+path.relative_to(run_root).as_posix()
            hashes[rel]=hashlib.sha256(data).hexdigest()
            z.writestr(rel,data)
    z.writestr('SNAPSHOT.json',json.dumps({'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'files':hashes},indent=2))
print(json.dumps({'archive':str(archive),'files':len(hashes),'bytes':archive.stat().st_size}),flush=True)
