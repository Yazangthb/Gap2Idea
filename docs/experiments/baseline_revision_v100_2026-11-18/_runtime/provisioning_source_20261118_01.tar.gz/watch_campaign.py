import datetime
import json
import pathlib
import subprocess
import time

root=pathlib.Path('/home/hamza/gap2idea-baselines')
while True:
    progress=json.loads(subprocess.check_output(['python3',str(root/'monitor_runs.py')],text=True))
    state=json.loads((root/'campaign-state.json').read_text())
    runs=[]
    for r in progress['runs']:
        name=r['model'].removesuffix(':latest').replace('qwen3.5-','3.5/').replace('qwen3.8-','3.8/').replace('-bf16','').replace('-fp8-dequant-f16','')
        runs.append(f"{name} {r['recorded_calls']}/{r['expected_calls']} calls, {r['failed_calls']} failed, {r['completed_configurations']} configs")
    now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).strftime('%H:%M:%S MSK')
    legacy=(root/'Gap2Idea/docs/experiments/baseline_revision_v100_legacy38_plan.json').exists()
    print(now+' | '+' | '.join(runs)+' | '+state['stage']+' | legacy_plan_ready='+str(legacy),flush=True)
    if state['stage'] in ['complete','needs_attention']:
        print(json.dumps(state),flush=True)
        break
    time.sleep(45)
