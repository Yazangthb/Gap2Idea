import hashlib
import json
import pathlib
import subprocess
import sys
import urllib.request

root = pathlib.Path('/home/hamza/gap2idea-baselines')
repo = root / 'Gap2Idea'
python = root / 'venv/bin/python'
models = ['qwen3.5-4b-bf16:latest','qwen3.5-9b-bf16:latest']
provenance = {'weights': {size:json.loads((root / f'weights/{size}/source.json').read_text()) for size in ['4B','9B']}}
provenance['ollama_binary_sha256'] = hashlib.sha256((root/'runtime/bin/ollama').read_bytes()).hexdigest()
provenance['runtime_allocation'] = {}
for port in [11445,11446]:
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/ps') as response:
        provenance['runtime_allocation'][str(port)] = json.load(response)
provenance['note'] = 'BF16 GGUF weights, no quantization; CUDA runner selected on V100. One active inference at a time per dedicated GPU. 27B begins only after both small jobs complete.'
prov_path = repo/'docs/experiments/baseline_revision_v100_small_weights.json'
prov_path.write_text(json.dumps(provenance,indent=2))
commands=[]
for port,devices in [(11445,'0,1'),(11446,'1')]:
    commands.append(f'env OLLAMA_HOST=127.0.0.1:{port} OLLAMA_MODELS={root}/models OLLAMA_NUM_PARALLEL=1 OLLAMA_MAX_LOADED_MODELS=1 OLLAMA_CONTEXT_LENGTH=131072 OLLAMA_FLASH_ATTENTION=0 CUDA_VISIBLE_DEVICES={devices} {root}/runtime/bin/ollama serve')
subprocess.run([str(python),'scripts/bench/baseline_matrix.py','prepare','--models',*models,
    '--plan','docs/experiments/baseline_revision_v100_small_plan.json',
    '--output-root',str(root/'runs/revision-v100-small-20261118-01'),
    '--weight-provenance',str(prov_path),'--server-command','\n'.join(commands)],cwd=repo,check=True)
