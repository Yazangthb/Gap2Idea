import hashlib
import json
import os
import pathlib
import subprocess
import time

root = pathlib.Path('/home/hamza/gap2idea-baselines')
weights = root / 'weights/27B'
while not (weights / 'source.json').exists():
    time.sleep(10)
source = json.loads((weights / 'source.json').read_text())
merged = weights / 'Qwen3.5-27B-BF16.gguf'
if not merged.exists():
    subprocess.run([str(root / 'llama.cpp/build/bin/llama-gguf-split'), '--merge',
                    str(weights / 'Qwen3.5-27B-BF16-00001-of-00002.gguf'), str(merged)], check=True)
sha = hashlib.sha256()
with merged.open('rb') as f:
    for block in iter(lambda: f.read(16 * 1024 * 1024), b''):
        sha.update(block)
source['merged_sha256'] = sha.hexdigest()
source['merge_tool_commit'] = subprocess.check_output(['git','-C',str(root/'llama.cpp'),'rev-parse','HEAD'],text=True).strip()
(weights / 'source-merged.json').write_text(json.dumps(source,indent=2))
modelfile = weights / 'Modelfile'
modelfile.write_text(f'FROM {merged}\nPARAMETER num_ctx 131072\nPARAMETER temperature 0\nPARAMETER repeat_penalty 1\n')
subprocess.run([str(root/'runtime/bin/ollama'),'create','qwen3.5-27b-bf16','-f',str(modelfile)],
               env=os.environ | {'OLLAMA_HOST':'127.0.0.1:11445'},check=True)
print('27B merged, verified and imported', flush=True)
