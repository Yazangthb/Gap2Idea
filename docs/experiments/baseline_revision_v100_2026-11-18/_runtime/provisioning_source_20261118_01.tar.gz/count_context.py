import json
import pathlib
import subprocess
import sys

root=pathlib.Path('/home/hamza/gap2idea-baselines')
repo=root/'Gap2Idea'
export = """
import sys,json
sys.path.insert(0,'scripts/bench')
import baseline_qwen as b
out=[]
for split in ('dev','test'):
    rows=b.load_rows('gold',split)
    for p in b.RUBRIC_NAMES:
        for u in b.units(rows,'A'):
            out.append(dict(split=split,prompt=p,unit=u['unit'],messages=[dict(role='system',content=b.build_prompt('gold',p)),dict(role='user',content=u['user'])]))
json.dump(out,open('/home/hamza/gap2idea-baselines/context-inputs.json','w'))
"""
subprocess.run([str(root/'venv/bin/python'),'-c',export],cwd=repo,check=True)
from transformers import AutoTokenizer
from huggingface_hub import HfApi
revision=HfApi().model_info('Qwen/Qwen3.5-27B').sha
sources={'3.5':('Qwen/Qwen3.5-27B',revision),'3.8':(str(root/'weights/legacy38-fp8'),None)}
payloads=json.loads((root/'context-inputs.json').read_text())
result={}
for generation,(source,rev) in sources.items():
    tok=AutoTokenizer.from_pretrained(source,revision=rev)
    lengths=[]
    for p in payloads:
        ids=tok.apply_chat_template(p['messages'],tokenize=True,add_generation_prompt=True,enable_thinking=False)
        lengths.append(dict(tokens=len(ids),unit=p['unit'],split=p['split'],prompt=p['prompt']))
    worst=max(lengths,key=lambda p:p['tokens'])
    result[generation]=dict(tokenizer_source=source,tokenizer_revision=rev,longest=worst,
                           output_budget=4096,minimum_context=worst['tokens']+4096,
                           safe_at_81920=worst['tokens']+4096<81920)
(root/'context-check.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2),flush=True)
