"""Continue only the committed campaign after both small-model jobs release the GPUs."""
import json
import pathlib
import subprocess
import time
import urllib.request

root=pathlib.Path('/home/hamza/gap2idea-baselines')
repo=root/'Gap2Idea'
python=root/'venv/bin/python'
state_file=root/'campaign-state.json'

def state(stage,**details):
    data=dict(stage=stage,updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**details)
    state_file.write_text(json.dumps(data,indent=2))
    print(json.dumps(data),flush=True)

def request(port,route,body=None):
    req=urllib.request.Request(f'http://127.0.0.1:{port}{route}',data=json.dumps(body).encode() if body is not None else None,
        headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=3600) as r: return json.load(r)

def all_recorded(report):
    return report['configurations']>0 and all(s['coverage']['all_calls_recorded'] for s in report['summaries'])

def wait_for_small():
    out=root/'runs/revision-v100-small-20261118-01'
    reports=[out/model/'test_report.json' for model in ['qwen3.5-4b-bf16-latest','qwen3.5-9b-bf16-latest']]
    while not all(p.exists() for p in reports):
        state('waiting_for_small_models')
        time.sleep(30)
    if not all(all_recorded(json.loads(p.read_text())) for p in reports):
        raise RuntimeError('Small-model campaign has unattempted calls')
    for port,model in [(11445,'qwen3.5-4b-bf16:latest'),(11446,'qwen3.5-9b-bf16:latest')]:
        request(port,'/api/generate',{'model':model,'keep_alive':0})

def wait_for_committed(plan_path):
    rel=plan_path.relative_to(repo).as_posix()
    while True:
        if plan_path.exists():
            logged=subprocess.run(['git','log','-1','--format=%H','--',rel],cwd=repo,capture_output=True,text=True,check=True).stdout.strip()
            dirty=subprocess.run(['git','status','--porcelain','--',rel],cwd=repo,capture_output=True,text=True,check=True).stdout.strip()
            if logged and not dirty: return
        state('waiting_for_committed_plan',plan=rel)
        time.sleep(30)

def run_model(plan_name):
    plan_path=repo/'docs/experiments'/plan_name
    wait_for_committed(plan_path)
    plan=json.loads(plan_path.read_text())
    model=next(iter(plan['models']))
    slug=model.replace(':','-').replace('/','-')
    out=pathlib.Path(plan['output_root'])
    for split in ['dev','test']:
        state('running_'+split,model=model,plan=plan_name)
        log=root/(slug+'-'+split+'.log')
        with log.open('a') as fh:
            subprocess.run([str(python),'scripts/bench/baseline_matrix.py','run','--plan',str(plan_path),
                '--split',split,'--base-url','http://127.0.0.1:11445'],cwd=repo,stdout=fh,stderr=subprocess.STDOUT,check=True)
        if split=='dev':
            allocation=request(11445,'/api/ps')
            loaded=next(m for m in allocation['models'] if m['name']==model)
            proof=dict(allocation=allocation,nvidia_smi=subprocess.check_output(['nvidia-smi'],text=True))
            proof_path=out/slug/('runtime_allocation_'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'.json')
            proof_path.write_text(json.dumps(proof,indent=2))
            if loaded['size_vram']<loaded['size']:
                raise RuntimeError('27B is partly on CPU; review memory allocation before any test call')
        else:
            report=json.loads((out/slug/'test_report.json').read_text())
            if not all_recorded(report): raise RuntimeError('Unattempted calls remain')
    subprocess.run([str(python),'scripts/bench/baseline_report.py',str(out)],cwd=repo,check=True)
    subprocess.run([str(python),str(root/'checkpoint_runs.py')],check=True)
    request(11445,'/api/generate',{'model':model,'keep_alive':0})

try:
    wait_for_small()
    for plan in ['baseline_revision_v100_27b_plan.json','baseline_revision_v100_legacy38_plan.json']:
        run_model(plan)
    state('complete')
except Exception as e:
    state('needs_attention',error=type(e).__name__+': '+str(e))
    raise
