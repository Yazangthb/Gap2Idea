import hashlib
import json
import pathlib
import subprocess
import time
import urllib.request

root=pathlib.Path('/home/hamza/gap2idea-baselines')
repo=root/'Gap2Idea'
python=root/'venv/bin/python'
entries=[('27b','qwen3.5-27b-bf16:latest',root/'weights/27B/source-merged.json'),
         ('legacy38','qwen3.8-27b-fp8-dequant-f16:latest',root/'weights/legacy38-f16/source.json')]
for label,model,source in entries:
    while True:
        with urllib.request.urlopen('http://127.0.0.1:11445/api/tags',timeout=30) as response:
            tags=json.load(response)['models']
        if source.exists() and any(t['name']==model for t in tags): break
        print('waiting for imported model',model,flush=True)
        time.sleep(30)
    provenance=dict(weights=json.loads(source.read_text()),context_check=json.loads((root/'context-check.json').read_text()),
        ollama_binary_sha256=hashlib.sha256((root/'runtime/bin/ollama').read_bytes()).hexdigest(),
        allocation='Both V100s, only after small-model completion. num_ctx=81920 exceeds the measured 76381-token input+output maximum. Full GPU residency is checked after development smoke and before test.')
    prov_path=repo/f'docs/experiments/baseline_revision_v100_{label}_weights.json'
    prov_path.write_text(json.dumps(provenance,indent=2))
    plan=repo/f'docs/experiments/baseline_revision_v100_{label}_plan.json'
    command=f'env OLLAMA_HOST=127.0.0.1:11445 OLLAMA_MODELS={root}/models OLLAMA_NUM_PARALLEL=1 OLLAMA_MAX_LOADED_MODELS=1 OLLAMA_CONTEXT_LENGTH=131072 OLLAMA_FLASH_ATTENTION=0 CUDA_VISIBLE_DEVICES=0,1 {root}/runtime/bin/ollama serve; per-call num_ctx=81920'
    subprocess.run([str(python),'scripts/bench/baseline_matrix.py','prepare','--models',model,
        '--plan',str(plan),'--output-root',str(root/f'runs/revision-v100-{label}-20261118-01'),
        '--num-ctx','81920','--weight-provenance',str(prov_path),'--server-command',command],cwd=repo,check=True)
    print('prepared',str(plan),flush=True)
