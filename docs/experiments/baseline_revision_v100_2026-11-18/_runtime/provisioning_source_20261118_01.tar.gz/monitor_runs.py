import collections
import json
import pathlib
import time

root=pathlib.Path('/home/hamza/gap2idea-baselines')
summary={'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'runs':[]}
for plan_path in sorted((root/'Gap2Idea/docs/experiments').glob('baseline_revision_v100_*_plan.json')):
    plan=json.loads(plan_path.read_text())
    out=pathlib.Path(plan['output_root'])
    for model in plan['models']:
        slug=model.replace(':','-').replace('/','-')
        paths=list((out/slug/'test').glob('*.jsonl'))
        records=[]
        for path in paths:
            # A growing file can end with an unfinished line; count only durable complete lines.
            data=path.read_bytes()
            for line in data.split(b'\n')[:-1]:
                if line.strip(): records.append(json.loads(line))
        entries=[r for r in plan['runs'] if r['model']==model and r['split']=='test']
        expected=sum(plan['expected'][__import__('hashlib').sha256(json.dumps(r,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()]['calls'] for r in entries)
        report_path=out/slug/'test_report.json'
        summary['runs'].append(dict(model=model,recorded_calls=len(records),expected_calls=expected,
            failed_calls=sum(r['status']!='ok' for r in records),
            failure_reasons=dict(collections.Counter(r.get('error','unspecified') for r in records if r['status']!='ok')),
            known_input_tokens=sum(a['prompt_tokens'] for r in records for a in r['attempt_log'] if a.get('prompt_tokens') is not None),
            known_output_tokens=sum(a['completion_tokens'] for r in records for a in r['attempt_log'] if a.get('completion_tokens') is not None),
            missing_cost_attempts=sum(a.get('prompt_tokens') is None or a.get('completion_tokens') is None for r in records for a in r['attempt_log']),
            attempts=sum(r['attempts'] for r in records),
            seconds=round(sum(r['seconds'] for r in records),1),
            completed_configurations=len(list((out/slug/'test').glob('*.summary.json'))),
            report_exists=report_path.exists()))
print(json.dumps(summary,indent=2),flush=True)
