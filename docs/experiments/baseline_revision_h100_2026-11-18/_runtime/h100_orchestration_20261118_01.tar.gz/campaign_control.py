"""Pause/resume only this user's Gap2Idea campaign. Completed calls are fsynced by baseline_qwen.

Install beside the campaign driver, outside the frozen repository. No credentials are printed.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import time
import urllib.request

ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT/'Gap2Idea'
H100=(REPO/'docs/experiments/baseline_revision_h100_plan.json').exists()
PLAN=REPO/('docs/experiments/baseline_revision_h100_plan.json' if H100 else 'docs/experiments/baseline_revision_v100_small_plan.json')
PYTHON=ROOT/'venv/bin/python'
OWNER=ROOT.stat().st_uid
STOP=ROOT/'STOP_REQUESTED'

def processes():
    found=[]
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            if p.stat().st_uid!=OWNER:continue
            args=(p/'cmdline').read_bytes().decode(errors='replace').strip('\0').split('\0')
            if len(args)<2:continue
            cwd=(p/'cwd').resolve()
            driver=(len(args)>2 and pathlib.Path(args[1]).name=='h100_campaign.py' and args[2]=='run' and pathlib.Path(args[1]).resolve().parent==ROOT)
            matrix=(cwd==REPO and 'run' in args and any(pathlib.Path(a).name=='baseline_matrix.py' for a in args[1:])
                    and '--plan' in args and pathlib.Path(args[args.index('--plan')+1]).name==PLAN.name)
            old_queue=(not H100 and len(args)>1 and pathlib.Path(args[1]).resolve()==ROOT/'continue_campaign.py')
            if driver or matrix or old_queue:found.append((int(p.name),'runner' if matrix else 'controller'))
        except (OSError,IndexError,ValueError):continue
    return found

def post(port,route,body=None):
    req=urllib.request.Request(f'http://127.0.0.1:{port}'+route,data=json.dumps(body).encode() if body is not None else None,
                              headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=60) as r:return json.load(r)

def checkpoint(repair=False):
    plan=json.loads(PLAN.read_text());runroot=pathlib.Path(plan['output_root']);files=[]
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    dest=ROOT/'checkpoints'/('paused-'+stamp)
    if repair:dest.mkdir(parents=True,exist_ok=False)
    for path in sorted(runroot.glob('*/*/*.jsonl')):
        data=path.read_bytes();valid=[];bad=False
        all_lines=data.splitlines(keepends=True)
        for index,line in enumerate(all_lines):
            try:json.loads(line)
            except (ValueError,UnicodeError):
                if any(x.strip() for x in all_lines[index+1:]):raise RuntimeError('Non-tail corruption requires manual recovery: '+str(path))
                bad=True;break
            valid.append(line if line.endswith(b'\n') else line+b'\n')
        cleaned=b''.join(valid)
        if repair and (bad or cleaned!=data):
            backup=dest/'original_bytes'/path.relative_to(runroot);backup.parent.mkdir(parents=True,exist_ok=True)
            backup.write_bytes(data)
            path.write_bytes(cleaned)
            data=cleaned
        records=[json.loads(x) for x in (cleaned if bad and not repair else data).splitlines() if x.strip()]
        files.append(dict(path=str(path.relative_to(runroot)),saved_calls=len(records),
            failed_calls=sum(r['status']!='ok' for r in records),last_saved_unit=records[-1]['unit'] if records else None,
            sha256=hashlib.sha256(data).hexdigest(),tail_repaired=bool(repair and bad)))
    report=dict(created_utc=dt.datetime.now(dt.timezone.utc).isoformat(),plan=str(PLAN),run_root=str(runroot),files=files,
        resume='Run this same script with resume; completed and failed recorded calls are skipped automatically.',
        interrupted_uncommitted_call_cost='missing: an in-flight call may be cancelled and repeated on resume; never treated as zero',
        control_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
    if repair:
        (dest/'CHECKPOINT.json').write_text(json.dumps(report,indent=2))
        (ROOT/'LAST_PAUSE.json').write_text(json.dumps(dict(checkpoint=str(dest/'CHECKPOINT.json')),indent=2))
    return report

def pause(dry=False):
    targets=processes()
    plan=json.loads(PLAN.read_text())
    names=['g2i-h100-20261118-'+m for m in plan['models']] if H100 else []
    if dry:
        print(json.dumps(dict(dry_run=True,processes=targets,containers=names,checkpoint=checkpoint(False)),indent=2));return
    STOP.write_text(dt.datetime.now(dt.timezone.utc).isoformat())
    for pid,kind in sorted(targets,key=lambda p:p[1]!='runner'):
        try:os.kill(pid,signal.SIGINT)
        except ProcessLookupError:pass
    deadline=time.monotonic()+20
    while processes() and time.monotonic()<deadline:time.sleep(1)
    for pid,_ in processes():
        try:os.kill(pid,signal.SIGTERM)
        except ProcessLookupError:pass
    time.sleep(2)
    if processes():raise RuntimeError('A campaign process is still stopping; no checkpoint repair performed')
    if H100:
        for name in names:
            state=subprocess.run(['docker','inspect','--format','{{.State.Status}}',name],capture_output=True,text=True)
            if state.returncode==0 and state.stdout.strip()=='running':
                subprocess.run(['docker','stop','-t','60',name],check=True)
    else:
        for port in [11445,11446]:
            try:
                for m in post(port,'/api/ps')['models']:post(port,'/api/generate',dict(model=m['name'],keep_alive=0,stream=False))
            except OSError:pass
    report=checkpoint(True)
    print(json.dumps(dict(status='paused',checkpoint=json.loads((ROOT/'LAST_PAUSE.json').read_text())['checkpoint'],
                         saved_calls=sum(x['saved_calls'] for x in report['files'])),indent=2))
    print(subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu','--format=csv,noheader'],text=True))

def resume():
    if processes():raise RuntimeError('Campaign is still running/stopping; refusing duplicate runners')
    plan=json.loads(PLAN.read_text());pending=set()
    for model,identity in plan['models'].items():
        report=pathlib.Path(plan['output_root'])/model.replace(':','-')/'test_report.json'
        complete=report.exists() and all(s['coverage']['all_calls_recorded'] for s in json.loads(report.read_text())['summaries'])
        if not complete:pending.add(identity['serving']['gpu'] if H100 else (0 if '4b' in model else 1))
    if not pending:
        print('All configured calls are already recorded; nothing to resume');return
    used=[int(v.strip()) for v in subprocess.check_output(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True).splitlines()]
    if any(used[gpu]>2048 for gpu in pending):raise RuntimeError('A required GPU is already in use; nothing started')
    if STOP.exists():STOP.unlink()
    if H100:
        with (ROOT/'campaign.log').open('a') as out:
            p=subprocess.Popen([str(PYTHON),str(ROOT/'h100_campaign.py'),'run'],cwd=REPO,stdout=out,stderr=subprocess.STDOUT,
                               stdin=subprocess.DEVNULL,start_new_session=True)
        print(json.dumps(dict(status='resuming',controller_pid=p.pid)));return
    plan=json.loads(PLAN.read_text())
    for model,port,devices,logname in [('qwen3.5-4b-bf16:latest',11445,'0,1','4b'),('qwen3.5-9b-bf16:latest',11446,'1','9b')]:
        report=pathlib.Path(plan['output_root'])/model.replace(':','-')/'test_report.json'
        if report.exists() and all(s['coverage']['all_calls_recorded'] for s in json.loads(report.read_text())['summaries']):continue
        try:post(port,'/api/version')
        except OSError:
            env=os.environ|dict(OLLAMA_HOST=f'127.0.0.1:{port}',OLLAMA_MODELS=str(ROOT/'models'),OLLAMA_NUM_PARALLEL='1',
                OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_CONTEXT_LENGTH='131072',OLLAMA_FLASH_ATTENTION='0',CUDA_VISIBLE_DEVICES=devices)
            with (ROOT/f'ollama-resume-{logname}.log').open('a') as out:
                subprocess.Popen([str(ROOT/'runtime/bin/ollama'),'serve'],env=env,stdout=out,stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,start_new_session=True)
            time.sleep(3)
        with (ROOT/f'test-{logname}.log').open('a') as out:
            p=subprocess.Popen([str(PYTHON),'scripts/bench/baseline_matrix.py','run','--plan',str(PLAN),'--split','test',
                '--models',model,'--base-url',f'http://127.0.0.1:{port}'],cwd=REPO,stdout=out,stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,start_new_session=True)
        print(json.dumps(dict(status='resuming',model=model,pid=p.pid)))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['pause','resume','status']);parser.add_argument('--dry-run',action='store_true');args=parser.parse_args()
    if os.geteuid() not in [0,OWNER]:raise SystemExit('Run as hamza, or use sudo -u hamza with administrator authorization')
    if args.action=='pause':pause(args.dry_run)
    elif args.action=='resume':resume()
    else:print(json.dumps(dict(processes=processes(),paused=STOP.exists(),checkpoint=checkpoint(False)),indent=2))
