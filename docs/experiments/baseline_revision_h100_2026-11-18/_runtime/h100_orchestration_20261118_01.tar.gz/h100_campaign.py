"""Pinned H100 campaign using the unchanged local baseline runner and its freeze checks."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import pathlib
import secrets
import subprocess
import sys
import time
import urllib.request
from types import SimpleNamespace as NS

ROOT=pathlib.Path('/home/hamza/gap2idea-h100-baselines')
REPO=ROOT/'Gap2Idea'
PYTHON=ROOT/'venv/bin/python'
PLAN=REPO/'docs/experiments/baseline_revision_h100_plan.json'
OUT=ROOT/'runs/matched-h100-20261118-01'
IMAGE='vllm/vllm-openai:v0.32.0'
SPECS={
 'qwen3.5-4b':dict(repo='Qwen/Qwen3.5-4B',revision='851bf6e8',gpu=0,port=8040,ctx=81920,size='4B'),
 'qwen3.5-9b':dict(repo='Qwen/Qwen3.5-9B',revision='c2022362',gpu=1,port=8041,ctx=81920,size='9B'),
 'qwen3.5-27b':dict(repo='Qwen/Qwen3.5-27B',revision='fc05daec18b0a78c049392ed2e771dde82bdf654',gpu=0,port=8040,ctx=81920,size='27B'),
 'qwen3.8-27b':dict(repo='Qwen/Qwen3.8-27B-FP8',revision='017b9c7af6b5689d5dd426a76e0bc077eb5ca20a',gpu=1,port=8041,ctx=262144,size='legacy38'),
}

sys.path[:0]=[str(REPO/'scripts/bench'),str(REPO/'src')]
import baseline_qwen as b
from baseline_matrix import grid
from baseline_evidence import code_hashes,committed,digest,fingerprint,git

def run(*args,**kwargs):
    return subprocess.run(*args,check=True,**kwargs)

def auth():
    key=ROOT/'api_key'
    if not key.exists():
        fd=os.open(key,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:f.write(secrets.token_urlsafe(32))
    env=ROOT/'server.env'
    if not env.exists():
        fd=os.open(env,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:f.write('VLLM_API_KEY='+key.read_text().strip()+'\n')
    return key.read_text().strip()

def api(port,route):
    req=urllib.request.Request(f'http://127.0.0.1:{port}'+route,headers={'Authorization':'Bearer '+auth()})
    with urllib.request.urlopen(req,timeout=10) as r:
        data=r.read()
        return json.loads(data) if data else None

def source_meta(spec):
    url=f"https://huggingface.co/api/models/{spec['repo']}/revision/{spec['revision']}?blobs=true"
    with urllib.request.urlopen(url,timeout=60) as r:meta=json.load(r)
    files=[f for f in meta['siblings'] if f['rfilename'].endswith(('.safetensors','.json','.jinja','.model','.txt'))]
    return meta['sha'],files

def server_args(model,identity):
    s=identity['serving']
    (ROOT/'runtime-cache'/model).mkdir(parents=True,exist_ok=True)
    args=['docker','run','--detach','--name','g2i-h100-20261118-'+model,
          '--gpus',f"device={s['gpu']}",'--ipc=host','--publish',f"127.0.0.1:{s['port']}:8000",
          '--env-file',str(ROOT/'server.env'),
          '--env','HF_HUB_OFFLINE=1','--env','VLLM_USE_FLASHINFER_SAMPLER=0','--env','VLLM_USE_DEEP_GEMM=0',
          '--volume',str(ROOT/'models')+':/models:ro',
          '--volume','/home/hamza/qwen5a/hf:/root/.cache/huggingface:ro',
          '--volume',str(ROOT/'runtime-cache'/model)+':/root/.cache/vllm',IMAGE]
    if s['size']=='legacy38':
        args += [identity['model_repo'],'--revision',identity['revision']]
    else:
        args += [f"/models/Qwen3.5-{s['size']}/{identity['revision']}"]
    args += ['--served-model-name',model,'--host','0.0.0.0','--port','8000',
             '--max-model-len',str(s['ctx']),'--max-num-seqs','64','--seed','0',
             '--dtype','bfloat16','--gpu-memory-utilization','0.85' if s['size']=='legacy38' else '0.90',
             '--reasoning-parser','qwen3']
    if s['size']=='legacy38':
        args += ['--speculative-config','{"method":"qwen3_next_mtp","num_speculative_tokens":2}']
    return args

def prepare():
    if PLAN.exists():raise RuntimeError('Use a fresh plan/root for a changed configuration')
    auth()
    image_id=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',IMAGE],text=True).strip()
    models={}
    for model,s in SPECS.items():
        revision,files=source_meta(s)
        models[model]=dict(model_repo=s['repo'],revision=revision,hf_files=files,
            dtype='bfloat16',quantization='FP8 checkpoint' if s['size']=='legacy38' else None,
            backend='vLLM',vllm_version='0.32.0',docker_image=IMAGE,docker_image_id=image_id,
            serving=s,thinking=False,seed=0,temperature=0)
        models[model]['launch_command']=server_args(model,models[model])
    cache={};prompts={};runs=[];expected={}
    for model,identity in models.items():
        for split,limit in [('dev',2),('test',0)]:
            for dataset,setup,prompt in grid(model):
                if (dataset,split) not in cache:cache[dataset,split]=b.load_rows(dataset,split)
                rows=cache[dataset,split]
                if limit:
                    pids=set(list(b.papers_of(rows))[:limit]);rows=[r for r in rows if r['pid'] in pids]
                if (dataset,prompt) not in prompts:prompts[dataset,prompt]=b.build_prompt(dataset,prompt)
                opts=NS(dataset=dataset,setup=setup,prompt=prompt,split=split,limit_papers=limit,
                    model=model,backend='openai',num_ctx=identity['serving']['ctx'])
                units=list(b.units(rows,setup));spec=fingerprint(opts,rows,units,prompts[dataset,prompt]);runs.append(spec)
                expected[digest(spec)]=dict(calls=len(units),sentences=len(rows),requested_sentences=sum(len(u['keys']) for u in units))
    plan=dict(created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),code_commit=git('rev-parse','HEAD'),
        code_hashes=code_hashes(),models=models,runs=runs,expected=expected,output_root=str(OUT),
        prepare_command=[sys.executable,str(pathlib.Path(__file__).resolve()),'prepare'],
        orchestration_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        hardware=subprocess.check_output(['nvidia-smi','--query-gpu=index,name,uuid,memory.total,driver_version','--format=csv,noheader'],text=True).strip(),
        protocol='Prospective H100/vLLM matched cohort after user authorized releasing both H100 Qwen reservations. '
          'Same prompts/data/seed/temperature/thinking/output budgets and AS/C definitions as the V100 plan. '
          'Pending27B configurations move to H100; V100 continues its existing4B/9B jobs. '
          'User explicitly retained the additional H1004B/9B controls after the27B runs. '
          'All three Qwen3.5 sizes use native unquantized BF16, max context81920, speculation off. '
          'Original Qwen3.8-27B-FP8 native control uses its original revision and MTP2/max context262144. '
          'One request at a time per GPU; GPU0:Qwen3.5-27B then4B, GPU1:Qwen3.8-27B then9B. '
          'GPU1 retains an unrelated approximately1GiB Python service, recorded in runtime proofs. '
          'Do not pool V100/Ollama and H100/vLLM timing or accuracy rows. '
          'All failures/retries retained; unknown costs null; all sentences scored including AS exclusions; '
          '2000 paper bootstrap draws seed0, paired differences funnel minus baseline.')
    PLAN.write_text(json.dumps(plan,indent=2))
    print(json.dumps(dict(plan=str(PLAN),test_configurations=sum(r['split']=='test' for r in runs),
        test_calls=sum(expected[digest(r)]['calls'] for r in runs if r['split']=='test')),indent=2),flush=True)

def verify_source(model,identity):
    s=identity['serving']
    if s['size']=='legacy38':
        path=pathlib.Path('/home/hamza/qwen5a/hf/hub/models--Qwen--Qwen3.8-27B-FP8/snapshots')/identity['revision']
        for spec in identity['hf_files']:
            p=path/spec['rfilename']
            h=hashlib.sha256()
            with p.open('rb') as f:
                for block in iter(lambda:f.read(16*1024*1024),b''):h.update(block)
            if 'lfs' in spec:
                if h.hexdigest()!=spec['lfs']['sha256']:raise RuntimeError('Cached model checksum mismatch: '+spec['rfilename'])
            else:
                data=p.read_bytes()
                if hashlib.sha1(b'blob %d\0'%len(data)+data).hexdigest()!=spec['blobId']:raise RuntimeError('Cached config checksum mismatch')
    else:
        source=ROOT/'models'/('Qwen3.5-'+s['size'])/identity['revision']/'SOURCE.json'
        while not source.exists():
            print('waiting for verified weights',model,flush=True);time.sleep(15)
        actual=json.loads(source.read_text())
        if (actual['repo'],actual['revision'],actual['files'])!=(identity['model_repo'],identity['revision'],identity['hf_files']):
            raise RuntimeError('Downloaded source differs from frozen model')

def worker(gpu,models,plan):
    for model in models:
        if (ROOT/'STOP_REQUESTED').exists():raise RuntimeError('Campaign paused by user')
        identity=plan['models'][model];serving=identity['serving'];name='g2i-h100-20261118-'+model
        done=OUT/model/'test_report.json'
        if done.exists():
            report=json.loads(done.read_text())
            if report['configurations']==len(grid(model)) and all(s['coverage']['all_calls_recorded'] for s in report['summaries']):continue
        verify_source(model,identity)
        if (ROOT/'STOP_REQUESTED').exists():raise RuntimeError('Campaign paused by user')
        command=server_args(model,identity)
        if command!=identity['launch_command']:raise RuntimeError('Serving command changed after freeze')
        print('starting',model,'on H100 GPU',gpu,flush=True)
        existing=subprocess.run(['docker','inspect','--format','{{.Image}}',name],capture_output=True,text=True)
        if existing.returncode==0:
            actual_cmd=json.loads(subprocess.check_output(['docker','inspect','--format','{{json .Config.Cmd}}',name],text=True))
            if existing.stdout.strip()!=identity['docker_image_id'] or actual_cmd!=command[command.index(IMAGE)+1:]:
                raise RuntimeError('Existing container differs from frozen profile: '+name)
            run(['docker','start',name])
        else:
            run(command)
        container_id=subprocess.check_output(['docker','inspect','--format','{{.Id}}',name],text=True).strip()
        try:
            deadline=time.monotonic()+1800
            while True:
                if (ROOT/'STOP_REQUESTED').exists():raise RuntimeError('Campaign paused by user')
                try:
                    available=api(serving['port'],'/v1/models')
                    if any(m['id']==model for m in available['data']):break
                except Exception:pass
                status=subprocess.check_output(['docker','inspect','--format','{{.State.Status}}',name],text=True).strip()
                if status!='running':raise RuntimeError('Model server exited: '+name)
                if time.monotonic()>deadline:raise RuntimeError('Model server readiness timed out')
                time.sleep(5)
            proof=dict(container=container_id,image_id=subprocess.check_output(['docker','inspect','--format','{{.Image}}',name],text=True).strip(),
                command=command,api_models=available,
                nvidia_smi=subprocess.check_output(['nvidia-smi'],text=True),
                version=api(serving['port'],'/version'))
            dest=OUT/model;dest.mkdir(parents=True,exist_ok=True)
            (dest/('runtime_allocation_'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'.json')).write_text(json.dumps(proof,indent=2))
            env=os.environ|{'QWEN_BASE_URL':f"http://127.0.0.1:{serving['port']}/v1",'QWEN_API_KEY':auth()}
            for split in ['dev','test']:
                if (ROOT/'STOP_REQUESTED').exists():raise RuntimeError('Campaign paused by user')
                print('running',model,split,flush=True)
                with (ROOT/(model+'-'+split+'.log')).open('a') as log:
                    run([str(PYTHON),'scripts/bench/baseline_matrix.py','run','--plan',str(PLAN),'--split',split,'--models',model],
                        cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
            print('completed',model,flush=True)
        finally:
            run(['docker','stop','-t','60',name])

def campaign():
    if (ROOT/'STOP_REQUESTED').exists():raise RuntimeError('Use campaign_control.py resume to clear the pause')
    if not committed(PLAN):raise RuntimeError('Commit the H100 plan before any campaign inference')
    plan=json.loads(PLAN.read_text())
    if plan['code_hashes']!=code_hashes():raise RuntimeError('Code changed after freeze')
    if plan['orchestration_sha256']!=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest():raise RuntimeError('Orchestration changed after freeze')
    auth()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(worker,0,['qwen3.5-27b','qwen3.5-4b'],plan),pool.submit(worker,1,['qwen3.8-27b','qwen3.5-9b'],plan)]
        for f in futures:f.result()
    run([str(PYTHON),'scripts/bench/baseline_report.py',str(OUT)],cwd=REPO)
    (ROOT/'COMPLETE.json').write_text(json.dumps(dict(completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),plan_sha256=digest(plan)),indent=2))
    print('H100 campaign complete',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['prepare','run']);args=parser.parse_args()
    {'prepare':prepare,'run':campaign}[args.command]()
