import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import urllib.request

root=pathlib.Path('/home/hamza/gap2idea-h100-baselines')
specs=[('4B','Qwen/Qwen3.5-4B','851bf6e8'),('9B','Qwen/Qwen3.5-9B','c2022362'),
       ('27B','Qwen/Qwen3.5-27B','fc05daec18b0a78c049392ed2e771dde82bdf654')]

def download_model(spec):
    size,repo,rev=spec
    with urllib.request.urlopen(f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true',timeout=60) as r:
        meta=json.load(r)
    revision=meta['sha']
    out=root/'models'/('Qwen3.5-'+size)/revision
    out.mkdir(parents=True,exist_ok=True)
    files=[f for f in meta['siblings'] if f['rfilename'].endswith(('.safetensors','.json','.jinja','.model','.txt'))]
    def one(f):
        name=f['rfilename']; path=out/name; path.parent.mkdir(parents=True,exist_ok=True)
        if not path.exists() or path.stat().st_size!=f['size']:
            with (out/'download.log').open('a') as log:
                subprocess.run(['curl','-fL','--retry','8','--retry-delay','3','-C','-','-o',str(path),
                    f'https://huggingface.co/{repo}/resolve/{revision}/{name}'],stdout=log,stderr=log,check=True)
        h=hashlib.sha256()
        with path.open('rb') as fp:
            for b in iter(lambda:fp.read(16*1024*1024),b''):h.update(b)
        if 'lfs' in f:
            assert h.hexdigest()==f['lfs']['sha256'],name
        else:
            data=path.read_bytes()
            assert hashlib.sha1(b'blob %d\0'%len(data)+data).hexdigest()==f['blobId'],name
        print('verified',size,name,flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(one,files))
    provenance=dict(repo=repo,revision=revision,files=files,snapshot=str(out),quantization=None,dtype='bfloat16')
    (out/'SOURCE.json').write_text(json.dumps(provenance,indent=2))
    print('READY',repo,revision,flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(download_model,specs))
