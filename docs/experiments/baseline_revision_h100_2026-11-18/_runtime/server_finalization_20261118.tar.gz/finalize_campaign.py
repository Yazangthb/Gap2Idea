"""Finish CPU reporting and snapshotting on the server, independent of SSH.

No inference is started or resumed. A paused/incomplete matrix simply stays pending.
"""
import datetime
import hashlib
import json
import pathlib
import subprocess
import time
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT / 'Gap2Idea'
H100 = (ROOT / 'h100_campaign.py').exists()
PLAN = REPO / ('docs/experiments/baseline_revision_h100_plan.json' if H100 else 'docs/experiments/baseline_revision_v100_small_plan.json')
plan = json.loads(PLAN.read_text())
OUT = pathlib.Path(plan['output_root'])

def recorded():
    for model in plan['models']:
        path = OUT / model.replace(':', '-') / 'test_report.json'
        try:
            report = json.loads(path.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            return False
        required = sum(r['split'] == 'test' and r['model'] == model for r in plan['runs'])
        if report['configurations'] != required or not all(s['coverage']['all_calls_recorded'] for s in report['summaries']):
            return False
    return True

print('Finalizer waiting for complete recorded matrices; no inference or resume is performed.', flush=True)
while True:
    if H100:
        ready = (ROOT / 'COMPLETE.json').exists()
    else:
        ready = recorded()
    if ready:
        break
    time.sleep(30)

if not recorded():
    raise RuntimeError('Completion marker does not match complete recorded matrices')
if not H100:
    subprocess.run([str(ROOT / 'venv/bin/python'), 'scripts/bench/baseline_report.py', str(OUT)], cwd=REPO, check=True)
    for model, port in [('qwen3.5-4b-bf16:latest', 11445), ('qwen3.5-9b-bf16:latest', 11446)]:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/ps', timeout=30) as response:
            loaded = json.load(response)['models']
        if not any(m['name'] == model for m in loaded):
            continue
        request = urllib.request.Request(f'http://127.0.0.1:{port}/api/generate',
            data=json.dumps(dict(model=model, keep_alive=0, stream=False)).encode(),
            headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(request, timeout=60) as response:
            if not json.load(response).get('done'):
                raise RuntimeError('Model unload failed')
    complete = dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    plan_file_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest(),
                    finalizer_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
                    note='All calls recorded; any recorded failures remain in the evidence. CPU scoring complete.')
    (ROOT / 'COMPLETE.json').write_text(json.dumps(complete, indent=2))

result = json.loads(subprocess.check_output(['python3', str(ROOT / ('checkpoint_h100.py' if H100 else 'checkpoint_runs.py'))], text=True))
result['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
result['finalizer_sha256'] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
(ROOT / 'LAST_COMPLETED_SNAPSHOT.json').write_text(json.dumps(result, indent=2))
print(json.dumps(dict(status='completed_and_snapshotted', **result)), flush=True)
