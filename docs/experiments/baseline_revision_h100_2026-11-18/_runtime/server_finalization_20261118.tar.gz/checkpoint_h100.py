import hashlib
import json
import pathlib
import time
import zipfile

root = pathlib.Path('/home/hamza/gap2idea-h100-baselines')
plan = json.loads((root / 'Gap2Idea/docs/experiments/baseline_revision_h100_plan.json').read_text())
run_root = pathlib.Path(plan['output_root'])
dest = root / 'checkpoints'
dest.mkdir(exist_ok=True)
archive = dest / ('h100-completed-' + time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '.zip')
files = set()
for summary in run_root.glob('*/*/*.summary.json'):
    stem = summary.name.removesuffix('.summary.json')
    for suffix in ['.jsonl', '.manifest.json', '.prompt.txt', '.summary.json']:
        files.add(summary.with_name(stem + suffix))
for pattern in ['*/smoke_report.json', '*/test_report.json', '*/runtime_allocation_*.json']:
    files.update(run_root.glob(pattern))
files.update(p for p in (run_root / 'handover').glob('*') if p.is_file())
hashes = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(files):
        data = path.read_bytes()
        rel = run_root.name + '/' + path.relative_to(run_root).as_posix()
        hashes[rel] = hashlib.sha256(data).hexdigest()
        z.writestr(rel, data)
    if (root / 'COMPLETE.json').exists():
        data = (root / 'COMPLETE.json').read_bytes()
        rel = run_root.name + '/COMPLETE.json'
        hashes[rel] = hashlib.sha256(data).hexdigest()
        z.writestr(rel, data)
    z.writestr('SNAPSHOT.json', json.dumps({'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'files': hashes}, indent=2))
print(json.dumps({'archive': str(archive), 'files': len(hashes), 'bytes': archive.stat().st_size}), flush=True)
