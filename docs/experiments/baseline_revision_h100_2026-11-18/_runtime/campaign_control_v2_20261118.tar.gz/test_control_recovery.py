"""Exercise pause checkpoint repair in a temporary directory; never touch active runs."""
import importlib.util
import json
import pathlib
import tempfile

source=pathlib.Path('/home/hamza/gap2idea-h100-baselines/campaign_control.py')
spec=importlib.util.spec_from_file_location('control_test',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='g2i-control-test-') as tmp:
    root=pathlib.Path(tmp);out=root/'runs';path=out/'model'/'test'/'case.jsonl';path.parent.mkdir(parents=True)
    records=[dict(unit='paper:0',status='ok'),dict(unit='paper:20',status='failed')]
    prefix=b''.join((json.dumps(r)+'\n').encode() for r in records)
    original=prefix+b'{"unit":"unfinished'
    path.write_bytes(original)
    plan=root/'plan.json';plan.write_text(json.dumps(dict(output_root=str(out))))
    module.ROOT=root;module.PLAN=plan
    report=module.checkpoint(True)
    assert path.read_bytes()==prefix
    pause=json.loads((root/'LAST_PAUSE.json').read_text())
    backup=pathlib.Path(pause['checkpoint']).parent/'original_bytes'/path.relative_to(out)
    assert backup.read_bytes()==original
    assert report['files'][0]['saved_calls']==2
    assert report['files'][0]['last_saved_unit']=='paper:20'
    assert report['files'][0]['tail_repaired']
print('PASS: durable prefix preserved, original partial bytes archived, resume position recorded')
